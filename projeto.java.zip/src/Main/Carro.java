/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

public class Main {
    public static void main(String[] args) {
        // Criando um objeto Scanner para entrada de dados pelo teclado
        Scanner scanner = new Scanner(System.in);
        
        // Criando um objeto Carro
        Carro meuCarro = new Carro();
        
        // Preenchendo os dados do carro
        meuCarro.preencher();
        
        // Imprimindo os dados do carro
        System.out.println("Dados do Carro:");
        meuCarro.imprimir();
        
        // Criando um objeto Roda
        Roda minhaRoda = new Roda();
        
        // Preenchendo os dados da roda
        minhaRoda.preencher();
        
        // Imprimindo os dados da roda
        System.out.println("Dados da Roda:");
        minhaRoda.imprimir();
        
        // Copiando os dados do carro para um novo objeto Carro
        Carro outroCarro = new Carro();
        outroCarro.Copiar(meuCarro);
        
        // Imprimindo os dados do novo carro
        System.out.println("Dados do Novo Carro:");
        outroCarro.imprimir();
    }
}

    


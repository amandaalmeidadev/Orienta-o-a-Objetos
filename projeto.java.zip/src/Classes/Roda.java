/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;
import java.io.InputStream;
import java.util.Scanner;

class Roda{	
    //atributos
    private double raio;
    private String material;
    private double peso;
    private double suporteMax;

    //métodos		
    public Roda(){ 
            this.raio = 0.0;
            this.material = "";
            this.peso = 0.0;
            this.suporteMax = 0.0;
    }
  
    public void setRaio (Double raio){
        this.raio = Raio;
    }
    
    public Double getRaio (){
        return raio;
    }
    
    public void setMaterial (String Material){
        this.material = Material;
    }
    public String getMaterial (){
        return material;
    }
    
    public void setPeso (Double Peso){
        this.peso =Peso;
    }
    
    public Double getPeso (){
        return peso;
    }
    
    public void setSuporteMax ( Double SuporteMax){
        this.suporteMax = SuporteMax;
    }
    
    public Double getSuporteMax (){
        return suporteMax;
    }
    
    public void preencher (){
        Scanner ler = Scanner(System.in);
        System.out.print("Informe os dados da Roda");
        
        System.out.print ("raio");
        this.raio = ler.nextDouble();
        
        System.out.print ("material");
        this.material = ler.next();
        
        
        System.out.println("peso");
        this.peso = ler.nextDouble();
        
        System.out.println("SuporteMax");
        this.suporteMax = ler.nextDouble;
   
    }
    
    public void imprimir (){
        System.out.print ("RAIO" + this.getRaio());
        System.out.print ("MATERIAL" + this.getMaterial());
        System.out.println("PESO"+ this.getPeso());
        System.out.println("SUPORTEMAX" + this.getSuporteMax());
    }
    
    public void Copiar (Roda outro){
        this.raio = outro.getRaio();
        this.material = outro.getMaterial();
        this.peso = outro.getPeso();
        this.suporteMax = outro.getSuporteMax();
        
    }

}



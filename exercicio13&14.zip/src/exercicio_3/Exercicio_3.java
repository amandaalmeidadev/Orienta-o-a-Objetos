/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio_3;


public class Exercicio_3 {

    
  
public class Main {
    public static void main(String[] args) {
        GerenciadordeMusicas gerenciador = new GerenciadordeMusicas();

        // Adicionando algumas músicas
        gerenciador.adicionarMúsica(new Musica("Shape of You", "Ed Sheeran", 2017));
        gerenciador.adicionarMúsica(new Musica("Bohemian Rhapsody", "Queen", 1975));
        gerenciador.adicionarMúsica(new Musica("Yesterday", "The Beatles", 1965));

        // Pesquisando uma música
        Musica músicaPesquisada = gerenciador.pesquisarMusica("Shape of You", "Ed Sheeran");
        if (musicaPesquisada != null) {
            System.out.println("Música encontrada: " + músicaPesquisada);
        } else {
            System.out.println("Música não encontrada.");
        }

        // Removendo uma música
        gerenciador.removerMusica("Bohemian Rhapsody", "Queen");
    }
}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class Musica {
    private String titulo;
    private String artista;
    private int anoLançamento;

    public Musica(String titulo, String artista, int anoLançamento) {
        this.titulo = titulo;
        this.artista = artista;
        this.anoLançamento = anoLançamento;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public int getAnoLançamento() {
        return anoLançamento;
    }

    @Override
    public String toString() {
        return "Música{" +
                "título='" + titulo + '\'' +
                ", artista='" + artista + '\'' +
                ", anoLançamento=" + anoLançamento +
                '}';
    }
}


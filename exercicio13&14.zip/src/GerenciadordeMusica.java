/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GerenciadordeMusica {
    private List<Musica> listaDeMusicas;

    public GerenciadordeMusica() {
        this.listaDeMusicas = new ArrayList<>();
    }

    public void adicionarMusica(Musica musica) {
        listaDeMusicas.add(musica);
    }

    public void removerMusica(String titulo, String artista) {
        Iterator<Musica> iterator = listaDeMusicas.iterator();
        while (iterator.hasNext()) {
            Musica musica = iterator.next();
            if (musica.getTitulo().equals(titulo) && musica.getArtista().equals(artista)) {
                iterator.remove();
                System.out.println("Música removida: " + musica);
                return;
            }
        }
        System.out.println("Música não encontrada.");
    }

    public Musica pesquisarMusica(String titulo, String artista) {
        for (Musica música : listaDeMusicas) {
            Musica musica = null;
            Object título = null;
            if (música.getTitulo().equals(título) && musica.getArtista().equals(artista)) {
                return musica;
            }
        }
        return null;
    }
}
